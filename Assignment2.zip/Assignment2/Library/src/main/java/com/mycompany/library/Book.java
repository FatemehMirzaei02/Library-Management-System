/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


public class Book extends Item {
    private int totalCopies;
    private int borrowedCopies;
    private DigitalCopy digitalCopy;

    
    public Book(int id, String title, String author, int pageCount, String topic, int totalCopies) {
        super(id, title, author, pageCount, topic);
        this.totalCopies = totalCopies;
        this.borrowedCopies = 0;
        this.digitalCopy = null;
    }

    /**
 * Adds one more physical copy of the book.
 */
    public void addCopy() {
        totalCopies++;

        if (state == ItemState.UNAVAILABLE) {
            state = ItemState.AVAILABLE;
        }
    }

    /**
 * Creates a digital copy for this book.
 */
    public void createDigitalCopy() {
        if (digitalCopy == null) {
            digitalCopy = new DigitalCopy(id);
        }
    }

    /**
 * Tries to borrow one physical copy of the book.
 */
    
    @Override
    public boolean borrow(Member member) {
        if (state == ItemState.ARCHIVED) {
            return false;
        }

        if (availableCopies() > 0) {
            borrowedCopies++;
            borrowCount++;

            if (availableCopies() == 0) {
                state = ItemState.UNAVAILABLE;
            } else {
                state = ItemState.BORROWED;
            }

            return true;
        }

        state = ItemState.UNAVAILABLE;
        return false;
    }

    /**
 * Handles returning this book and updates its state.
 */
    
    @Override
    public void returnItem(Condition condition) {
        if (borrowedCopies <= 0) {
            throw new IllegalStateException("No borrowed copies to return.");
        }

        borrowedCopies--;

        if (condition == Condition.PRESERVED) {
            state = ItemState.AVAILABLE;
        } else {
            state = ItemState.NEEDS_REPAIR;
        }
    }

    /**
 * Calculates how many copies are still available.
 */
    public int availableCopies() {
        return totalCopies - borrowedCopies;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public int getBorrowedCopies() {
        return borrowedCopies;
    }

    public DigitalCopy getDigitalCopy() {
        return digitalCopy;
    }
}
