/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */



public class Main {
    public static void main(String[] args) {
        Library library = new Library();

        Book book = new Book(
                1,
                "Clean_Code",
                "Robert_C_Martin",
                464,
                "Software_Engineering",
                3
        );

        Thesis thesis = new Thesis(
                2,
                "AI_Thesis",
                "John_Doe",
                120,
                "Artificial_Intelligence",
                1,
                "Dr_Smith",
                2023
        );

        ResearchPaper paper = new ResearchPaper(
                3,
                "Deep_Learning_Survey",
                "Jane_Roe",
                30,
                "Machine_Learning"
        );

        Member student = new Member(
                1,
                "Bence_Nagy",
                "bence@elte.hu",
                MemberCategory.STUDENT
        );

        Member faculty = new Member(
                2,
                "Eszter_Kovacs",
                "eszter@elte.hu",
                MemberCategory.FACULTY
        );

        library.addItem(book);
        library.addItem(thesis);
        library.addItem(paper);

        library.addMember(student);
        library.addMember(faculty);

        System.out.println("Library simulation started.");

        book.createDigitalCopy();
        book.getDigitalCopy().view();
        book.getDigitalCopy().download();

        System.out.println("Digital copy created for: " + book.getTitle());
        System.out.println("Views: " + book.getDigitalCopy().getViews());
        System.out.println("Downloads: " + book.getDigitalCopy().getDownloads());

        boolean bookBorrowed = library.borrowItem(student, book);
        System.out.println("Student borrowed book: " + bookBorrowed);
        System.out.println("Book borrowed copies: " + book.getBorrowedCopies());

        boolean bookReturned = library.returnItem(student, book, Condition.PRESERVED);
        System.out.println("Book returned preserved: " + bookReturned);
        System.out.println("Book state after return: " + book.getState());
        System.out.println("Student total returned items: " + student.getTotalReturnedItems());

        boolean thesisBorrowed = library.borrowItem(faculty, thesis);
        System.out.println("Faculty borrowed thesis: " + thesisBorrowed);

        boolean thesisReturned = library.returnItem(faculty, thesis, Condition.DAMAGED);
        System.out.println("Thesis returned damaged: " + thesisReturned);
        System.out.println("Thesis state after damaged return: " + thesis.getState());

        library.periodicRepairCheck();
        System.out.println("Periodic repair check executed.");
        System.out.println("Thesis state after repair check: " + thesis.getState());

        paper.borrow(student);
        System.out.println("Research paper accessed.");
        System.out.println("Research paper views: " + paper.getViews());
        System.out.println("Research paper borrow count: " + paper.getBorrowCount());

        System.out.println("Search by title result count: "
                + library.searchByTitle("Clean_Code").size());

        System.out.println("Most popular item: "
                + library.findMostPopularItem().getTitle());

        Item mostViewedDigitalItem = library.findMostViewedDigitalItem();
        if (mostViewedDigitalItem != null) {
            System.out.println("Most viewed digital item: "+ mostViewedDigitalItem.getTitle());
        }
    }
}