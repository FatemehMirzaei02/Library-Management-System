/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.library;

/**
 *
 * @author Asus
 */

import java.util.ArrayList;
import java.util.List;


public class Library {
    private List<Item> items;
    private List<Member> members;
    private List<Transaction> transactions;
    private RepairsSection repairsSection;

    
    public Library() {
        this.items = new ArrayList<>();
        this.members = new ArrayList<>();
        this.transactions = new ArrayList<>();
        this.repairsSection = new RepairsSection();
    }

    /**
 * Adds a new item to the library collection.
 */
    public void addItem(Item item) {
        if (items.contains(item)) {
            throw new IllegalStateException("Item already exists.");
        }

        items.add(item);
    }

    /**
 * Adds a new member to the library.
 */
    public void addMember(Member member) {
        if (members.contains(member)) {
            throw new IllegalStateException("Member already exists.");
        }

        members.add(member);
    }

    /**
 * Finds items with the given title.
 */
    public List<Item> searchByTitle(String title) {
        List<Item> result = new ArrayList<>();

        for (Item item : items) {
            if (item.getTitle().equalsIgnoreCase(title)) {
                result.add(item);
            }
        }

        return result;
    }

    /**
 * Finds items written by the given author.
 */
    public List<Item> searchByAuthor(String author) {
        List<Item> result = new ArrayList<>();

        for (Item item : items) {
            if (item.getAuthor().equalsIgnoreCase(author)) {
                result.add(item);
            }
        }

        return result;
    }

    /**
 * Tries to borrow an item for a member.
 */
    public boolean borrowItem(Member member, Item item) {
        if (!members.contains(member)) {
            return false;
        }

        if (!items.contains(item)) {
            return false;
        }

        if (!member.canBorrow()) {
            return false;
        }

        boolean success = item.borrow(member);

        if (success) {
            member.borrow(item);
            transactions.add(new Transaction(member, item, "borrow"));
        }

        return success;
    }

    /**
 * Handles returning an item to the library.
 */
    public boolean returnItem(Member member, Item item, Condition condition) {
        if (!members.contains(member)) {
            return false;
        }

        if (!items.contains(item)) {
            return false;
        }

        if (!member.getBorrowedItems().contains(item)) {
            return false;
        }

        item.returnItem(condition);
        member.returnItem(item, condition);
        transactions.add(new Transaction(member, item, "return", condition));

        if (condition == Condition.DAMAGED) {
            item.setState(ItemState.NEEDS_REPAIR);
        }

        return true;
    }

   /**
 * Sends items that need repair to the repairs section.
 */
    public void periodicRepairCheck() {
        for (Item item : new ArrayList<>(items)) {
            if (item.getState() == ItemState.NEEDS_REPAIR) {
                repairsSection.repair(item);

                if (item.getState() == ItemState.ARCHIVED) {
                    items.remove(item);
                }
            }
        }
    }

    /**
 * Finds the member with the most returned items.
 */
    public Member findMostActiveMember() {
        Member best = null;

        for (Member member : members) {
            if (best == null ||
                member.getTotalReturnedItems() > best.getTotalReturnedItems()) {
                best = member;
            }
        }

        return best;
    }
/**
 * Finds the item that has been used the most.
 */
   
    public Item findMostPopularItem() {
        Item best = null;

        for (Item item : items) {
            if (best == null || item.getBorrowCount() > best.getBorrowCount()) {
                best = item;
            }
        }

        return best;
    }

 /**
 * Finds the book with the most viewed digital copy.
 */
   
    public Item findMostViewedDigitalItem() {
        Book best = null;

        for (Item item : items) {
            if (item instanceof Book book && book.getDigitalCopy() != null) {
                if (best == null ||
                    book.getDigitalCopy().getViews() > best.getDigitalCopy().getViews()) {
                    best = book;
                }
            }
        }

        return best;
    }

    /**
 * Finds the book with the most downloaded digital copy.
 */
    public Item findMostDownloadedDigitalItem() {
        Book best = null;

        for (Item item : items) {
            if (item instanceof Book book && book.getDigitalCopy() != null) {
                if (best == null ||
                    book.getDigitalCopy().getDownloads() > best.getDigitalCopy().getDownloads()) {
                    best = book;
                }
            }
        }

        return best;
    }

    public List<Item> getItems() {
        return items;
    }

    public List<Member> getMembers() {
        return members;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public RepairsSection getRepairsSection() {
        return repairsSection;
    }
}