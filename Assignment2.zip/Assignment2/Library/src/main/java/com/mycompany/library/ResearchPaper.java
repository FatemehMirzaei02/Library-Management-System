/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


public class ResearchPaper extends Item {
    private int views;
    private int downloads;

   
    public ResearchPaper(int id, String title, String author, int pageCount, String topic) {
        super(id, title, author, pageCount, topic);
        this.views = 0;
        this.downloads = 0;
    }

    
    @Override
    public boolean borrow(Member member) {
        view();
        return true;
    }

    /**
 * Rejects physical return because research papers are online only.
 */
    @Override
    public void returnItem(Condition condition) {
        throw new UnsupportedOperationException("Research papers are not physically returned.");
    }

    /**
 * Increases the view counter.
 */
    public void view() {
        views++;
        borrowCount++;
    }

    /**
 * Increases the download counter.
 */
    public void download() {
        downloads++;
        borrowCount++;
    }

    public int getViews() {
        return views;
    }

    public int getDownloads() {
        return downloads;
    }
}
