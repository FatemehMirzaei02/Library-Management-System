/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


public class Thesis extends Item {
    private String advisor;
    private int defenseYear;
    private int totalCopies;
    private int borrowedCopies;

    
    public Thesis(int id, String title, String author, int pageCount, String topic,
                  int totalCopies, String advisor, int defenseYear) {
        super(id, title, author, pageCount, topic);
        this.totalCopies = totalCopies;
        this.borrowedCopies = 0;
        this.advisor = advisor;
        this.defenseYear = defenseYear;
    }

   /**
 * Tries to borrow one physical copy of the thesis.
 */
    @Override
    public boolean borrow(Member member) {
        if (state == ItemState.ARCHIVED) {
            return false;
        }

        if (availableCopies() > 0) {
            borrowedCopies++;
            borrowCount++;

            if (availableCopies() == 0) {
                state = ItemState.UNAVAILABLE;
            } else {
                state = ItemState.BORROWED;
            }

            return true;
        }

        state = ItemState.UNAVAILABLE;
        return false;
    }

    /**
 * Handles returning this thesis and updates its state.
 */
    @Override
    public void returnItem(Condition condition) {
        if (borrowedCopies <= 0) {
            throw new IllegalStateException("No borrowed copies to return.");
        }

        borrowedCopies--;

        if (condition == Condition.PRESERVED) {
            state = ItemState.AVAILABLE;
        } else {
            state = ItemState.NEEDS_REPAIR;
        }
    }

    /**
 * Calculates how many thesis copies are still available.
 */
    public int availableCopies() {
        return totalCopies - borrowedCopies;
    }

    public String getAdvisor() {
        return advisor;
    }

    public int getDefenseYear() {
        return defenseYear;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public int getBorrowedCopies() {
        return borrowedCopies;
    }
}
