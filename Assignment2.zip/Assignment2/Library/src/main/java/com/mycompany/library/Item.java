/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


public abstract class Item {
    protected int id;
    protected String title;
    protected String author;
    protected int pageCount;
    protected String topic;
    protected int borrowCount;
    protected ItemState state;

    
    public Item(int id, String title, String author, int pageCount, String topic) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.pageCount = pageCount;
        this.topic = topic;
        this.borrowCount = 0;
        this.state = ItemState.AVAILABLE;
    }

   
    public abstract boolean borrow(Member member);

   
    public abstract void returnItem(Condition condition);

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getBorrowCount() {
        return borrowCount;
    }

    public ItemState getState() {
        return state;
    }

    public void setState(ItemState state) {
        this.state = state;
    }
}
