/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */

import java.time.LocalDateTime;


public class Transaction {
    private static int nextId = 1;

    private int id;
    private Member member;
    private Item item;
    private String type;
    private LocalDateTime date;
    private Condition condition;

    /**
 * Creates a transaction for borrowing an item.
 */
    public Transaction(Member member, Item item, String type) {
        this.id = nextId++;
        this.member = member;
        this.item = item;
        this.type = type;
        this.date = LocalDateTime.now();
        this.condition = null;
    }

    /**
 * Creates a transaction for returning an item.
 */
    public Transaction(Member member, Item item, String type, Condition condition) {
        this.id = nextId++;
        this.member = member;
        this.item = item;
        this.type = type;
        this.date = LocalDateTime.now();
        this.condition = condition;
    }

    public int getId() {
        return id;
    }

    public Member getMember() {
        return member;
    }

    public Item getItem() {
        return item;
    }

    public String getType() {
        return type;
    }

    public Condition getCondition() {
        return condition;
    }
}
