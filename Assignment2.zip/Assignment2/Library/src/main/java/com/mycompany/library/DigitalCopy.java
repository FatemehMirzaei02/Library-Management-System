/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


public class DigitalCopy {
    private int id;
    private int views;
    private int downloads;

   
    public DigitalCopy(int id) {
        this.id = id;
        this.views = 0;
        this.downloads = 0;
    }

    /**
 * Increases the number of views.
 */
    public void view() {
        views++;
    }

    /**
 * Increases the number of downloads.
 */
    public void download() {
        downloads++;
    }

    public int getId() {
        return id;
    }

    public int getViews() {
        return views;
    }

    public int getDownloads() {
        return downloads;
    }
}