/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */

import java.util.ArrayList;
import java.util.List;


public class Member {
    private int id;
    private String name;
    private String email;
    private MemberCategory category;
    private int borrowLimit;
    private int totalReturnedItems;
    private int returnedPreservedCount;
    private List<Item> borrowedItems;

    
    public Member(int id, String name, String email, MemberCategory category) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.category = category;
        this.borrowLimit = 3;
        this.totalReturnedItems = 0;
        this.returnedPreservedCount = 0;
        this.borrowedItems = new ArrayList<>();
    }

   /**
 * Checks if the member can borrow another item.
 */
    public boolean canBorrow() {
        return borrowedItems.size() < borrowLimit;
    }

   /**
 * Adds an item to the member's borrowed items.
 */
    public void borrow(Item item) {
        if (!canBorrow()) {
            throw new IllegalStateException("Borrow limit reached.");
        }

        if (borrowedItems.contains(item)) {
            throw new IllegalStateException("Item already borrowed by this member.");
        }

        borrowedItems.add(item);
    }

   /**
 * Removes a returned item and updates the member statistics.
 */
    public void returnItem(Item item, Condition condition) {
        if (!borrowedItems.contains(item)) {
            throw new IllegalStateException("This item was not borrowed by this member.");
        }

        borrowedItems.remove(item);
        totalReturnedItems++;

        if (condition == Condition.PRESERVED) {
            returnedPreservedCount++;

            if (returnedPreservedCount % 3 == 0) {
                borrowLimit++;
            }
        }
    }

    public int getId() {
        return id;
    }

    public int getBorrowLimit() {
        return borrowLimit;
    }

    public int getTotalReturnedItems() {
        return totalReturnedItems;
    }

    public int getReturnedPreservedCount() {
        return returnedPreservedCount;
    }

    public List<Item> getBorrowedItems() {
        return borrowedItems;
    }

    public String getName() {
        return name;
    }
}
