 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */


import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class RepairsSection {
    private int repairCount;
    private List<Item> archivedItems;
    private Random random;

   
    
    
    public RepairsSection() {
        this.repairCount = 0;
        this.archivedItems = new ArrayList<>();
        this.random = new Random();
    }

    /**
 * Repairs an item or archives it if the damage is too serious.
 */
    
    public void repair(Item item) {
        if (item.getState() != ItemState.NEEDS_REPAIR) {
            throw new IllegalStateException("Item does not need repair.");
        }

        repairCount++;
        item.setState(ItemState.BEING_REPAIRED);

        if (isSevere()) {
            item.setState(ItemState.ARCHIVED);
            archivedItems.add(item);
        } else {
            item.setState(ItemState.AVAILABLE);
        }
    }

    /**
 * checks if the damage is severe.
 */
    public boolean isSevere() {
        return random.nextDouble() < 0.3;
    }

    public int getRepairCount() {
        return repairCount;
    }

    public List<Item> getArchivedItems() {
        return archivedItems;
    }
}
