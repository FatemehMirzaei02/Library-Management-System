/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author Asus
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LibraryTest {

    @Test
    public void testBorrowBookSuccessfully() {
        Library library = new Library();
        Book book = new Book(1, "Clean_Code", "Robert", 400, "Programming", 2);
        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        library.addItem(book);
        library.addMember(member);

        boolean result = library.borrowItem(member, book);

        assertTrue(result);
        assertEquals(1, book.getBorrowedCopies());
        assertEquals(1, book.getBorrowCount());
        assertTrue(member.getBorrowedItems().contains(book));
    }

    @Test
    public void testBorrowFailsIfMemberNotRegistered() {
        Library library = new Library();
        Book book = new Book(1, "Clean_Code", "Robert", 400, "Programming", 1);
        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        library.addItem(book);

        boolean result = library.borrowItem(member, book);

        assertFalse(result);
        assertEquals(0, book.getBorrowedCopies());
    }

    @Test
    public void testBorrowFailsWhenLimitReached() {
        Library library = new Library();
        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        Book b1 = new Book(1, "B1", "A", 100, "T", 1);
        Book b2 = new Book(2, "B2", "A", 100, "T", 1);
        Book b3 = new Book(3, "B3", "A", 100, "T", 1);
        Book b4 = new Book(4, "B4", "A", 100, "T", 1);

        library.addMember(member);
        library.addItem(b1);
        library.addItem(b2);
        library.addItem(b3);
        library.addItem(b4);

        assertTrue(library.borrowItem(member, b1));
        assertTrue(library.borrowItem(member, b2));
        assertTrue(library.borrowItem(member, b3));
        assertFalse(library.borrowItem(member, b4));
    }

    @Test
    public void testReturnPreservedBook() {
        Library library = new Library();
        Book book = new Book(1, "Clean_Code", "Robert", 400, "Programming", 1);
        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        library.addItem(book);
        library.addMember(member);

        library.borrowItem(member, book);
        boolean result = library.returnItem(member, book, Condition.PRESERVED);

        assertTrue(result);
        assertEquals(ItemState.AVAILABLE, book.getState());
        assertFalse(member.getBorrowedItems().contains(book));
        assertEquals(1, member.getTotalReturnedItems());
    }

    @Test
    public void testBorrowLimitIncreasesAfterThreePreservedReturns() {
        Library library = new Library();
        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        Book b1 = new Book(1, "B1", "A", 100, "T", 1);
        Book b2 = new Book(2, "B2", "A", 100, "T", 1);
        Book b3 = new Book(3, "B3", "A", 100, "T", 1);

        library.addMember(member);
        library.addItem(b1);
        library.addItem(b2);
        library.addItem(b3);

        library.borrowItem(member, b1);
        library.returnItem(member, b1, Condition.PRESERVED);

        library.borrowItem(member, b2);
        library.returnItem(member, b2, Condition.PRESERVED);

        library.borrowItem(member, b3);
        library.returnItem(member, b3, Condition.PRESERVED);

        assertEquals(4, member.getBorrowLimit());
        assertEquals(3, member.getReturnedPreservedCount());
    }

    @Test
    public void testDamagedReturnNeedsRepair() {
        Library library = new Library();
        Thesis thesis = new Thesis(1, "AI_Thesis", "John", 120, "AI", 1, "Dr_Smith", 2024);
        Member member = new Member(1, "Sara", "sara@test.com", MemberCategory.FACULTY);

        library.addItem(thesis);
        library.addMember(member);

        library.borrowItem(member, thesis);
        boolean result = library.returnItem(member, thesis, Condition.DAMAGED);

        assertTrue(result);
        assertEquals(ItemState.NEEDS_REPAIR, thesis.getState());
    }

    @Test
    public void testDigitalCopyViewsAndDownloads() {
        Book book = new Book(1, "Clean_Code", "Robert", 400, "Programming", 1);

        book.createDigitalCopy();

        book.getDigitalCopy().view();
        book.getDigitalCopy().view();
        book.getDigitalCopy().download();

        assertEquals(2, book.getDigitalCopy().getViews());
        assertEquals(1, book.getDigitalCopy().getDownloads());
    }

    @Test
    public void testFindMostViewedDigitalItem() {
        Library library = new Library();

        Book b1 = new Book(1, "B1", "A", 100, "T", 1);
        Book b2 = new Book(2, "B2", "A", 100, "T", 1);

        b1.createDigitalCopy();
        b2.createDigitalCopy();

        b1.getDigitalCopy().view();

        b2.getDigitalCopy().view();
        b2.getDigitalCopy().view();

        library.addItem(b1);
        library.addItem(b2);

        assertEquals(b2, library.findMostViewedDigitalItem());
    }

    @Test
    public void testResearchPaperBorrowCountsAsView() {
        ResearchPaper paper = new ResearchPaper(
                1,
                "Deep_Learning_Survey",
                "Jane",
                30,
                "Machine_Learning"
        );

        Member member = new Member(1, "Ali", "ali@test.com", MemberCategory.STUDENT);

        boolean result = paper.borrow(member);

        assertTrue(result);
        assertEquals(1, paper.getViews());
        assertEquals(1, paper.getBorrowCount());
    }

    @Test
    public void testSearchByTitle() {
        Library library = new Library();
        Book book = new Book(1, "Clean_Code", "Robert", 400, "Programming", 1);

        library.addItem(book);

        assertEquals(1, library.searchByTitle("Clean_Code").size());
        assertEquals(book, library.searchByTitle("Clean_Code").get(0));
    }
}